package unlam.progava.oia;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import Grafos.GrafoDirigidoPonderado;

public class Archivo {

	public static Rescate leerArchivo(String pathArchivo) throws FileNotFoundException {
		
		try (Scanner reader = new Scanner(new FileReader(pathArchivo))) {
			
			ArrayList<Integer> posDragones=new ArrayList<Integer>();
			int cantClaros=reader.nextInt();
			int cantSenderos=reader.nextInt();
			int cantDragones=reader.nextInt();
			int posPrincesa=reader.nextInt();
			int posPrincipe=reader.nextInt();
			
			for(int i=0;i<cantDragones;i++) {
				posDragones.add(reader.nextInt());
			}
			
			int[][] matrizAdyacencia = new int [cantClaros][cantClaros];
			
			for(int i = 0; i < cantClaros; i++)//COMPLETA MATRIZ CON INFINITOS
				for(int j = 0; j < cantClaros; j++)
					matrizAdyacencia[i][j] = Integer.MAX_VALUE;
			
			for(int i=0;i<cantSenderos;i++) {
				matrizAdyacencia[reader.nextInt()-1][reader.nextInt()-1]=reader.nextInt();
			}
			
			GrafoDirigidoPonderado grafo = new GrafoDirigidoPonderado(matrizAdyacencia);
			return new Rescate(grafo,posDragones,posPrincesa,posPrincipe);
			}
		}
	
	
	public static void escribirArchivo(String pathArchivoSalida, String resultado) throws IOException {

			BufferedWriter buffer = new BufferedWriter(new FileWriter(new File(pathArchivoSalida)));
			buffer.write(resultado);
			buffer.close();
	}

}
