package unlam.progava.oia;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

import Grafos.GrafoDirigidoPonderado;

public class Rescate {
	private GrafoDirigidoPonderado grafo;
	private ArrayList<Integer> dragones;
	private int posPrincesa;
	private int posPrincipe;
	private String resultado="";
	
	public Rescate(GrafoDirigidoPonderado grafo, ArrayList<Integer> dragones, int posPrincesa, int posPrincipe) {
		this.grafo = grafo;
		this.dragones = dragones;
		this.posPrincesa = posPrincesa;
		this.posPrincipe = posPrincipe;
	}

	public void resolver() {

		int costominimoPrincipe = grafo.realizarDijkstraConCamino(posPrincipe)[posPrincesa-1];
		if(costominimoPrincipe==Integer.MAX_VALUE)
			resultado = "No hay camino";
		for (Integer drag : dragones) {
				if(grafo.realizarDijkstra(drag)[posPrincesa-1]<=costominimoPrincipe) {
					resultado = "Interceptado";
				}
		}
		if(resultado=="") {
			
			ArrayList <Integer> camino = grafo.reconstruirCaminoDijkstra(posPrincesa);
			Collections.reverse(camino);
			resultado=formatearSalida(camino);
		}
	}
	
	public GrafoDirigidoPonderado getGrafo() {
		return grafo;
	}

	public void setGrafo(GrafoDirigidoPonderado grafo) {
		this.grafo = grafo;
	}

	public ArrayList<Integer> getDragones() {
		return dragones;
	}

	public void setDragones(ArrayList<Integer> dragones) {
		this.dragones = dragones;
	}

	public int getPosPrincesa() {
		return posPrincesa;
	}

	public void setPosPrincesa(int posPrincesa) {
		this.posPrincesa = posPrincesa;
	}

	public int getPosPrincipe() {
		return posPrincipe;
	}

	public void setPosPrincipe(int posPrincipe) {
		this.posPrincipe = posPrincipe;
	}
	
	public static String formatearSalida(ArrayList<Integer> res) {
		String resultado = "";
		
		for (Integer integer : res) {
			resultado += integer.toString() + " ";
		}
		
		return resultado.trim();
	
	}

	public String getResultado() {
		return resultado;
	}

	public void setResultado(String resultado) {
		this.resultado = resultado;
	}


}
