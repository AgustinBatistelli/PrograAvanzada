package unlam.progava.oia;

import java.io.FileNotFoundException;
import java.io.IOException;

public class EjercicioOIA {
	
	private Rescate rescate;
	
	public static void main(String[] args) throws IOException {
		EjercicioOIA ejercicio = new EjercicioOIA();
		ejercicio.leer("src/unlam/progava/oia/in/00.in");
		ejercicio.resolver();
		ejercicio.escribir("src/unlam/progava/oia/out/00.out");
	}
	
	public void leer(String path) throws IOException {
		rescate = Archivo.leerArchivo(path);
		
	}
	
	public void escribir(String path) throws IOException{
		Archivo.escribirArchivo(path, this.rescate.getResultado());
		
	}
	
	public void resolver() {
		rescate.resolver();
		
	}
}
