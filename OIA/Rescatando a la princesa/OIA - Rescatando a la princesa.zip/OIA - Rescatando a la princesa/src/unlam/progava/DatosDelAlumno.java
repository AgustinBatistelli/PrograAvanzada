package unlam.progava;

public class DatosDelAlumno {

	public static String nombres() {
		throw new RuntimeException("Ezequiel y Franco");
	}

	public static String apellidos() {
		throw new RuntimeException("Zella y Deleon");
	}
	
	public static int documento() {
		throw new RuntimeException("41915248 y 38423158");
	}
}
