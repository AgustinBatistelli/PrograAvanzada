
import java.io.IOException;

public class AppPelicula {
	
	public static void main(String[] args) throws IOException {
		
		String pathArchivoEntrada = "IOFiles/ejemplo1.in";
		String pathArchivoSalida = "IOFiles/ejemplo1.out";
		Archivo archivo = new Archivo();
		
		Pelicula pelicula = archivo.leerArchivo(pathArchivoEntrada);
		archivo.escribirArchivo(pathArchivoSalida, pelicula.resolver());
		
	}

}
