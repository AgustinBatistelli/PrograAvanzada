import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class Pelicula {

	ArrayList<Segmento> segmentos;
	GrafoDirigidoPonderado grafo;

	public Pelicula(ArrayList<Segmento> segmentos, GrafoDirigidoPonderado grafo) {
		this.segmentos = segmentos;
		this.grafo = grafo;
	}

	public ArrayList<Segmento> getSegmentos() {
		return segmentos;
	}

	public void setSegmentos(ArrayList<Segmento> segmentos) {
		this.segmentos = segmentos;
	}

	public GrafoDirigidoPonderado getGrafo() {
		return grafo;
	}

	public void setGrafo(GrafoDirigidoPonderado grafo) {
		this.grafo = grafo;
	}

	public String resolver() {

		ArrayList<Integer> segmentosIniciales = getSegmentosIniciales();
		ArrayList<Integer> segmentosFinales = getSegmentosFinales();
		int[] vectorDistancias = new int[this.segmentos.size()];
		String resultado = "";
		int minimoCosto = Integer.MAX_VALUE;

		for (Integer integer : segmentosIniciales) {

			vectorDistancias = this.grafo.realizarDijkstraConCamino(integer);

			for (Integer integer2 : segmentosFinales) {
				if (minimoCosto > vectorDistancias[integer2 - 1]) {
					minimoCosto = vectorDistancias[integer2 - 1];
					resultado = "";
					ArrayList<Integer> camino = this.grafo.reconstruirCaminoDijkstra(integer2);
					Collections.reverse(camino);
					resultado = Pelicula.formatearSalida(camino);
				}
			}
	
		}
		
		if(minimoCosto == Integer.MAX_VALUE)
			resultado = "No es posible";

		return resultado;

	}

	public ArrayList<Integer> getSegmentosIniciales() {

		ArrayList<Integer> segmentosIniciales = new ArrayList<Integer>();

		for (int i = 0; i < this.segmentos.size(); i++) {
			if (segmentos.get(i).isEsInicial() == true) {
				segmentosIniciales.add(segmentos.get(i).getIdSegmento());
			}
		}

		return segmentosIniciales;

	}

	public ArrayList<Integer> getSegmentosFinales() {

		ArrayList<Integer> segmentosFinales = new ArrayList<Integer>();

		for (int i = 0; i < this.segmentos.size(); i++) {
			if (segmentos.get(i).isEsFinal() == true) {
				segmentosFinales.add(segmentos.get(i).getIdSegmento());
			}
		}

		return segmentosFinales;

	}
	
	public static String formatearSalida(ArrayList<Integer> res) {
		String resultado = "";
		
		for (Integer integer : res) {
			resultado += integer.toString() + " ";
		}
		
		return resultado.trim();
		
	}

}
