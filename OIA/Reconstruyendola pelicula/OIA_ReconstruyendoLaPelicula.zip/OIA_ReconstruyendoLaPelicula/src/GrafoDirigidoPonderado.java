
import java.util.ArrayList;


public class GrafoDirigidoPonderado extends Grafo{ ///TIPO DE GRAFO DE DIJKSTRA, FLOYD, WARSHALL
	
	private int [] padres; //Se utiliza para reconstruir el camino con el menor costo en Dijkstra
	
	public GrafoDirigidoPonderado(int [][] matriz) { //ALGORITMO DE DIJKSTRA
		this.matrizAdyacencia = matriz;
		this.padres = new int[matriz.length];
	}
	
	
	///ALGORITMO DE DIJKSTRA
	public int[] getPadres() {
		return padres;
	}

	public void setPadres(int[] padres) {
		this.padres = padres;
	}

	public int[] realizarDijkstra(int nodoInicial) {
		return Dijkstra.dijkstra(nodoInicial, this);
	}
	
	public int[] realizarDijkstraConCamino(int nodoInicial) {
		return Dijkstra.dijkstraConCamino(nodoInicial, this);
	}
	
	public ArrayList<Integer> reconstruirCaminoDijkstra(int nodoFinal){
		return Dijkstra.reconstruirCamino(nodoFinal, this);
	}

	
}
