import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Archivo {

	public Pelicula leerArchivo(String pathArchivo) throws FileNotFoundException {

		ArrayList<Segmento> segmentos = new ArrayList<Segmento>();

		try (Scanner reader = new Scanner(new FileReader(pathArchivo))) {

			int cantidadSegmentos = reader.nextInt();
			int escenaFinal = reader.nextInt();

			for (int i = 0; i < cantidadSegmentos; i++) {
				Segmento segmento = new Segmento(reader.nextInt(), reader.nextInt(), reader.nextInt());
				if (segmento.getEscenaInicial() == 1)
					segmento.setEsInicial(true);
				if (segmento.getEscenaFinal() == escenaFinal)
					segmento.setEsFinal(true);

				segmentos.add(segmento);

			}

			int[][] matrizAdyacencia = new int[segmentos.size()][segmentos.size()];

			for (int z = 0; z < segmentos.size(); z++)
				for (int y = 0; y < segmentos.size(); y++)
					matrizAdyacencia[z][y] = Integer.MAX_VALUE;

			for (int j = 1; j < segmentos.size(); j++) {
				for (int k = j - 1; k >= 0; k--) {

					if (segmentos.get(k).getEscenaFinal() >= segmentos.get(j).getEscenaInicial()
							&& segmentos.get(k).getEscenaInicial() != segmentos.get(j).getEscenaInicial() && matrizAdyacencia[j][k] == Integer.MAX_VALUE) {
						matrizAdyacencia[j][k] = (segmentos.get(k).getEscenaFinal()
								- segmentos.get(j).getEscenaInicial()) + 1;
						matrizAdyacencia[k][j] = (segmentos.get(k).getEscenaFinal()
								- segmentos.get(j).getEscenaInicial()) + 1;
					}
				}
			}
			
			GrafoDirigidoPonderado grafo = new GrafoDirigidoPonderado(matrizAdyacencia);
			return new Pelicula(segmentos, grafo);
		}
		
	}
	
	
	public void escribirArchivo(String pathArchivoSalida, String resultado) throws IOException {

			BufferedWriter buffer = new BufferedWriter(new FileWriter(new File(pathArchivoSalida)));
			buffer.write(resultado);
			buffer.close();
	
	}

}
