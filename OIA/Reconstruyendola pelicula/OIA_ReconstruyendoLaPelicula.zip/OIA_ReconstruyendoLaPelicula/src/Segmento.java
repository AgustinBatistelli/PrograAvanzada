
public class Segmento {
	
	private int idSegmento;
	private int escenaInicial;
	private int escenaFinal;
	private boolean esInicial;
	private boolean esFinal;
	
	public Segmento(int idSegmento, int escenaInicial, int escenaFinal) {
		this.idSegmento = idSegmento;
		this.escenaInicial = escenaInicial;
		this.escenaFinal = escenaFinal;
		this.esInicial = false;
		this.esFinal = false;
	}

	public int getIdSegmento() {
		return idSegmento;
	}

	public void setIdSegmento(int idSegmento) {
		this.idSegmento = idSegmento;
	}

	public int getEscenaInicial() {
		return escenaInicial;
	}

	public void setEscenaInicial(int escenaInicial) {
		this.escenaInicial = escenaInicial;
	}

	public int getEscenaFinal() {
		return escenaFinal;
	}

	public void setEscenaFinal(int escenaFinal) {
		this.escenaFinal = escenaFinal;
	}

	public boolean isEsInicial() {
		return esInicial;
	}

	public void setEsInicial(boolean esInicial) {
		this.esInicial = esInicial;
	}

	public boolean isEsFinal() {
		return esFinal;
	}

	public void setEsFinal(boolean esFinal) {
		this.esFinal = esFinal;
	}
	
	
	
	
	

}
