package unlam.progava.oia;

public class Segmento {
	private int idSegmento;
	private int inicio;
	private int fin;
	private int prin_Fin;
	
	
	public Segmento(int idSegmento, int inicio, int fin) {
		super();
		this.idSegmento = idSegmento;
		this.inicio = inicio;
		this.fin = fin;
	}
	public int getInicio() {
		return inicio;
	}
	public void setInicio(int inicio) {
		this.inicio = inicio;
	}
	public int getFin() {
		return fin;
	}
	public void setFin(int fin) {
		this.fin = fin;
	}
	public int getIdSegmento() {
		return idSegmento;
	}
	public void setIdSegmento(int idSegmento) {
		this.idSegmento = idSegmento;
	}
	public int getPrin_Fin() {
		return prin_Fin;
	}
	public void setPrin_Fin(int prin_Fin) {
		this.prin_Fin = prin_Fin;
	}
	
}
