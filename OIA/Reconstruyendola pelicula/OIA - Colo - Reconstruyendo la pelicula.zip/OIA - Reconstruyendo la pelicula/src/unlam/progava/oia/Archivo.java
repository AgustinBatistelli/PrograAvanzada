package unlam.progava.oia;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import Grafos.GrafoDirigidoPonderado;

public class Archivo {

	public static Pelicula leerArchivo(String pathArchivo) throws FileNotFoundException {

		try (Scanner reader = new Scanner(new FileReader(pathArchivo))) {
			
			ArrayList<Segmento> pelicula = new ArrayList<Segmento>();
			int cantsegm = reader.nextInt();
			int escenaFinal = reader.nextInt();
			int[][] matrizAdyacencia = new int[cantsegm][cantsegm];
			
			for (int i = 0; i < cantsegm; i++)// COMPLETA MATRIZ CON INFINITOS
				for (int j = 0; j < cantsegm; j++)
					matrizAdyacencia[i][j] = Integer.MAX_VALUE;

			for (int i = 0; i < cantsegm; i++) {
				Segmento segm = new Segmento(0,0,0);
				segm.setIdSegmento(reader.nextInt());
				segm.setInicio(reader.nextInt());
				segm.setFin(reader.nextInt());
				if(segm.getInicio()==1)
					segm.setPrin_Fin(1);
				if(segm.getFin()==escenaFinal)
					segm.setPrin_Fin(2);
				pelicula.add(segm);
				for (int k = i - 1; k >= 0; k--) {
					if (pelicula.get(k).getFin() >= pelicula.get(i).getInicio()
							&& matrizAdyacencia[i][k] == Integer.MAX_VALUE 
							&& pelicula.get(i).getFin()> pelicula.get(k).getFin()) {
						matrizAdyacencia[k][i] = (pelicula.get(k).getFin() - pelicula.get(i).getInicio()) + 1;
					}else if(pelicula.get(k).getFin() >= pelicula.get(i).getInicio()
							&& matrizAdyacencia[i][k] == Integer.MAX_VALUE 
							&& pelicula.get(i).getFin()< pelicula.get(k).getFin()) {
						matrizAdyacencia[i][k] = (pelicula.get(i).getFin() - pelicula.get(k).getInicio()) + 1;
					}
				}
			}
			GrafoDirigidoPonderado grafo = new GrafoDirigidoPonderado(matrizAdyacencia);
			Pelicula peli = new Pelicula(pelicula, grafo);
			return peli;
		}
	}

	public static void escribirArchivo(String pathArchivoSalida, String resultado) throws IOException {

		BufferedWriter buffer = new BufferedWriter(new FileWriter(new File(pathArchivoSalida)));
		buffer.write(resultado.toString());// VER TIPO DE DATO (VER INTEGER.toString(resultado))
		buffer.close();
	}

}
