package unlam.progava.oia;

import java.util.ArrayList;
import java.util.Collections;

import Algoritmos.Dijkstra;
import Grafos.GrafoDirigidoPonderado;

public class Pelicula {
	ArrayList<Segmento> segmentos;
	GrafoDirigidoPonderado grafo;
	String resultado;

	public Pelicula(ArrayList<Segmento> segmentos, GrafoDirigidoPonderado grafo) {
		this.segmentos = segmentos;
		this.grafo = grafo;
	}

	public void resolver() {
		int[] vectorDistancias = null;
		int menorCosto=Integer.MAX_VALUE;
		ArrayList<Integer> finales = new ArrayList<Integer>();
		
		for(int i=0;i<segmentos.size();i++) {
			if(segmentos.get(i).getPrin_Fin()==1)
				vectorDistancias=grafo.realizarDijkstraConCamino(i+1);
			if(segmentos.get(i).getPrin_Fin()==2) {
				finales.add(segmentos.get(i).getIdSegmento());
			}
		}
		for (int integer : finales) {
			if (menorCosto > vectorDistancias[integer - 1]) {
				menorCosto = vectorDistancias[integer - 1];
				ArrayList<Integer> camino = this.grafo.reconstruirCaminoDijkstra(integer);
				Collections.reverse(camino);
				resultado = Pelicula.formatearSalida(camino);
			}
		}
		System.out.println(resultado);
	}

	public String getResultado() {
		return resultado;
	}

	public void setResultado(String resultado) {
		this.resultado = resultado;
	}

	public ArrayList<Segmento> getSegmentos() {
		return segmentos;
	}

	public void setSegmentos(ArrayList<Segmento> segmentos) {
		this.segmentos = segmentos;
	}

	public GrafoDirigidoPonderado getGrafo() {
		return grafo;
	}

	public void setGrafo(GrafoDirigidoPonderado grafo) {
		this.grafo = grafo;
	}
	
	public static String formatearSalida(ArrayList<Integer> res) {
		String resultado = "";
		
		for (Integer integer : res) {
			resultado += integer.toString() + " ";
		}
		
		return resultado.trim();
		
	}

}
