package unlam.progava.oia;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

import Grafos.GrafoNoDirigidoPonderado;

public class Archivo {

	public static Reserva leerArchivo(String pathArchivo) throws FileNotFoundException {

		try (Scanner reader = new Scanner(new FileReader(pathArchivo))) {
		
			int cantidadMiradores = reader.nextInt();
			int cantidadTramos = reader.nextInt();
			
			int[][] matrizAdyacencia = new int[cantidadMiradores][cantidadMiradores];		
			for(int i = 0; i < cantidadMiradores; i++)//COMPLETA MATRIZ CON INFINITOS
				for(int j = 0; j < cantidadMiradores; j++)
					matrizAdyacencia[i][j] = Integer.MAX_VALUE;
			
			for(int i = 0; i < cantidadTramos; i++) {
				int miradorA = reader.nextInt();
				int miradorB = reader.nextInt();
				matrizAdyacencia[miradorA-1][miradorB-1] = 1;
			}
			
			GrafoNoDirigidoPonderado grafo = new GrafoNoDirigidoPonderado(matrizAdyacencia);
			
			return new Reserva(1, cantidadMiradores, grafo);
			
			}
		
}
	
	
	public static void escribirArchivo(String pathArchivoSalida, int resultado) throws IOException {

			BufferedWriter buffer = new BufferedWriter(new FileWriter(new File(pathArchivoSalida)));
			buffer.write(Integer.toString(resultado));//VER TIPO DE DATO (VER INTEGER.toString(resultado))
			buffer.close();
	}

}
