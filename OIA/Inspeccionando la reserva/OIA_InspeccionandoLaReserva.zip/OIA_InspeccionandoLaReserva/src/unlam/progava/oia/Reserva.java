package unlam.progava.oia;

import Grafos.GrafoNoDirigidoPonderado;

public class Reserva {
	
	private GrafoNoDirigidoPonderado grafo;
	private int resultado;
	private int miradorInicio;
	private int miradorFin;
	
	
	
	public int getMiradorInicio() {
		return miradorInicio;
	}


	public void setMiradorInicio(int miradorInicio) {
		this.miradorInicio = miradorInicio;
	}


	public int getMiradorFin() {
		return miradorFin;
	}


	public void setMiradorFin(int miradorFin) {
		this.miradorFin = miradorFin;
	}


	public Reserva(int miradorInicio, int miradorFin, GrafoNoDirigidoPonderado grafo) {
		
		this.miradorInicio = miradorInicio;
		this.miradorFin = miradorFin;
		this.grafo = grafo;
		this.resultado = 0;
	}


	public GrafoNoDirigidoPonderado getGrafo() {
		return grafo;
	}

	public void setGrafo(GrafoNoDirigidoPonderado grafo) {
		this.grafo = grafo;
	}

	public int getResultado() {
		return resultado;
	}

	public void setResultado(int resultado) {
		this.resultado = resultado;
	}
	
	
	public void resolver() {
		this.resultado = grafo.cantidadCaminosPosibles(this.miradorInicio);
	}
	
	
	
}
