package unlam.progava.oia;

import java.util.ArrayList;

public class Invitado {
	
	private int idInvitado;
	private ArrayList<Integer> enemigos;
	

	public Invitado(int idInvitado) {
		this.idInvitado = idInvitado;
		this.enemigos = new ArrayList<Integer>();
	}
	
	public int getIdInvitado() {
		return idInvitado;
	}
	public void setIdInvitado(int idInvitado) {
		this.idInvitado = idInvitado;
	}
	public ArrayList<Integer> getEnemigos() {
		return enemigos;
	}
	public void setEnemigos(ArrayList<Integer> enemigos) {
		this.enemigos = enemigos;
	}
	
	

}
