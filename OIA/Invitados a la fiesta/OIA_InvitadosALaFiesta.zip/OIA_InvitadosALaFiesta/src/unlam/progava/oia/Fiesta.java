package unlam.progava.oia;

import java.util.ArrayList;

public class Fiesta {
	
	private ArrayList<Invitado> invitados;
	private GrafoNoDirigidoPonderado grafo;
	private int resultado;
	
	public Fiesta(ArrayList<Invitado> invitados, GrafoNoDirigidoPonderado grafo) {
		super();
		this.invitados = invitados;
		this.grafo = grafo;
		this.resultado = 0;
	}
	
	public ArrayList<Invitado> getInvitados() {
		return invitados;
	}
	public void setInvitados(ArrayList<Invitado> invitados) {
		this.invitados = invitados;
	}
	public GrafoNoDirigidoPonderado getGrafo() {
		return grafo;
	}
	public void setGrafo(GrafoNoDirigidoPonderado grafo) {
		this.grafo = grafo;
	}

	public int getResultado() {
		return resultado;
	}

	public void setResultado(int resultado) {
		this.resultado = resultado;
	}
	
	public void resolver() {
		
		int maxCantidadInvitados = Integer.MIN_VALUE;
		ArrayList<ArrayList<Integer>> conjuntos;
		conjuntos = this.grafo.realizarColoreo(100);
		
		for (ArrayList<Integer> arrayList : conjuntos) {
			if(arrayList.size() > maxCantidadInvitados)
				maxCantidadInvitados = arrayList.size();
		}
		
		this.resultado = maxCantidadInvitados;
		
	}
	

}
