package unlam.progava.oia;

import java.io.FileNotFoundException;
import java.io.IOException;

public class EjercicioOIA {
	
	private Fiesta fiesta;

	public static void main(String[] args) throws IOException {
		EjercicioOIA ejercicio = new EjercicioOIA();
		ejercicio.leer("src/unlam/progava/oia/in/01.in");
		ejercicio.resolver();
		ejercicio.escribir("src/unlam/progava/oia/out/01.out");
	}

	public void leer(String path) throws FileNotFoundException {
		fiesta = Archivo.leerArchivo(path);
		
	}
	
	public void escribir(String path) throws IOException {
		Archivo.escribirArchivo(path, this.fiesta.getResultado());
	}
	
	public void resolver() {
		fiesta.resolver();
	}
}
