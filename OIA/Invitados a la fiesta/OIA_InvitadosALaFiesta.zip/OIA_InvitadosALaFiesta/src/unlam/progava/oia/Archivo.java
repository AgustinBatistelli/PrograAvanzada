package unlam.progava.oia;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Archivo {

	public static Fiesta leerArchivo(String pathArchivo) throws FileNotFoundException {

		ArrayList<Invitado> invitados = new ArrayList<Invitado>();

		try (Scanner reader = new Scanner(new FileReader(pathArchivo))) {

			int cantidadInvitados = reader.nextInt();
			int cantidadConflictos = reader.nextInt();

			for (int i = 0; i < cantidadInvitados; i++)
				invitados.add(new Invitado(i+1));
			
			for(int i = 0; i < cantidadConflictos; i++) {
				int idInvitadoA = reader.nextInt();
				int idInvitadoB = reader.nextInt();
				
				invitados.get(idInvitadoA-1).getEnemigos().add(idInvitadoB);
				invitados.get(idInvitadoB-1).getEnemigos().add(idInvitadoA);
			}
		
			int[][] matrizAdyacencia = new int[invitados.size()][invitados.size()];
			
			for(int i = 0; i < invitados.size(); i++)
				for(int j = 0; j < invitados.size(); j++)
					matrizAdyacencia[i][j] = Integer.MAX_VALUE;
			
			for (Invitado invitado : invitados) {
				for (Integer enemigo : invitado.getEnemigos()) {
					matrizAdyacencia[invitado.getIdInvitado()-1][enemigo-1] = 1;
				}
			}

			GrafoNoDirigidoPonderado grafo = new GrafoNoDirigidoPonderado(matrizAdyacencia);
			
			return new Fiesta(invitados, grafo);
		}
		
	}
	
	
	public static void escribirArchivo(String pathArchivoSalida, int resultado) throws IOException {

			BufferedWriter buffer = new BufferedWriter(new FileWriter(new File(pathArchivoSalida)));
			buffer.write(Integer.toString(resultado));
			buffer.close();
	
	}

}
